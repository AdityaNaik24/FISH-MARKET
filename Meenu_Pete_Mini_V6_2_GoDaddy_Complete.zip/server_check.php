<?php
/* Read-only administrator hosting health check. Never expose secrets or credentials. */
declare(strict_types=1);
if(PHP_VERSION_ID<80200){http_response_code(503);exit('Select PHP 8.2 or newer in cPanel.');}
require_once __DIR__.'/lib.php';
session_init();
try {
    $db=database();
    $u=require_actor($db,['admin']);
    $settings=get_setting($db);
    $db->query('SELECT COUNT(*) FROM announcement_votes')->fetchColumn();
    $voteTable=true;
    $db->query('SELECT token_hash FROM remembered_users LIMIT 0');
} catch(Throwable $e) {
    error_log('Meenu Pete Mini V6.2 check: '.$e->getMessage());
    http_response_code(503);
    exit('Health check unavailable. Sign in as admin and verify MySQL configuration/migration.');
}
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
$checks=[
 'PHP version 8.2 or newer'=>version_compare(PHP_VERSION,'8.2.0','>='),
 'pdo_mysql enabled'=>extension_loaded('pdo_mysql'),
 'fileinfo enabled'=>extension_loaded('fileinfo'),
 'iconv enabled'=>extension_loaded('iconv'),
 'MySQL database connected'=>($db instanceof PDO),
 'Announcement voting table'=>($voteTable??false),
 'Announcement revision field'=>array_key_exists('announcement_version',$settings),
 'Logo and menu-video fields'=>array_key_exists('logo_path',$settings)&&array_key_exists('promo_video_path',$settings),
 'Persistent-login table'=>true,
 'Uploads folder writable'=>is_writable(__DIR__.'/uploads'),
];
$all=true;
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Meenu Pete Mini V6.2 · Hosting Check</title><style>body{font-family:system-ui,sans-serif;background:#f4f8f8;color:#153747;max-width:680px;margin:35px auto;padding:15px}main{background:white;border:1px solid #d8e6e4;border-radius:16px;padding:24px}h1{font-size:22px}table{border-collapse:collapse;width:100%}td{border-bottom:1px solid #e0e9e9;padding:11px 7px}td:last-child{text-align:right;font-weight:bold}.pass{color:#007856}.fail{color:#aa3a2b}a{color:#007e80}</style></head><body><main><h1>🐟 Meenu Pete Mini V6.2 – Hosting Check</h1><p>Read-only checks for the authenticated administrator. No credentials are displayed.</p><table><?php foreach($checks as $name=>$pass):$all=$all&&$pass;?><tr><td><?=htmlspecialchars($name,ENT_QUOTES,'UTF-8')?></td><td class="<?=$pass?'pass':'fail'?>"><?=$pass?'PASS':'CHECK'?></td></tr><?php endforeach;?></table><p>PHP upload_max_filesize: <?=htmlspecialchars(ini_get('upload_max_filesize'))?>; post_max_size: <?=htmlspecialchars(ini_get('post_max_size'))?>. For 25 MB video, set upload_max_filesize to at least 25M and post_max_size to at least 32M.</p><p><strong><?=$all?'All listed checks passed.':'One or more settings need attention.'?></strong></p><p><a href="index.html">Return to Meenu Pete / ಮೀನು ಪೇಟೆಗೆ ಹಿಂತಿರುಗಿ</a></p></main></body></html>
