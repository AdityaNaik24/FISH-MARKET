<?php
/* One-time Mini V5 setup. Delete setup.php after installation. */
declare(strict_types=1);
require_once __DIR__.'/lib.php';
header('Content-Type: text/html; charset=utf-8');header('Cache-Control: no-store');
session_init();
function page(string $inner):never{
 echo '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Meenu Pete Mini Setup</title><style>body{background:#eef5f6;font:15px system-ui;color:#163643;padding:24px}main{max-width:520px;background:white;border-radius:16px;padding:24px;margin:auto;box-shadow:0 5px 25px #16364312}input{width:100%;padding:12px;border-radius:8px;border:1px solid #c3d2d4;box-sizing:border-box;margin:8px 0 16px}button{background:#008f91;color:white;border:0;padding:13px 18px;border-radius:8px;font-weight:800}p{line-height:1.6}</style><main><h1>🐟 ಮೀನು ಪೇಟೆ MINI · Setup</h1>'.$inner.'</main></html>';exit;
}
if(is_file(__DIR__.'/install.lock'))page('<p>Already installed. Delete setup.php from the server.</p>');
if(str_starts_with(INSTALL_SECRET,'REPLACE_')||strlen(INSTALL_SECRET)<32)page('<p>Edit <code>config.php</code>: enter cPanel database credentials and a unique 32+ character INSTALL_SECRET. Then import <code>database.sql</code>.</p>');
try{$db=database();$db->query('SELECT id FROM settings WHERE id=1')->fetch();if((int)$db->query('SELECT COUNT(*) FROM admins')->fetchColumn()>0)page('<p>An administrator already exists. Setup is locked; do not overwrite accounts. Delete setup.php after checking the website.</p>');}catch(Throwable $e){page('<p>Database not ready. Create the MySQL database, grant all permissions to its user, and import database.sql via phpMyAdmin.</p>');}
if(($_SERVER['REQUEST_METHOD']??'GET')!=='POST')page('<p>Create your first administrator account. No sample or default admin password is provided.</p><form method="post"><label>Private installation key<input type="password" name="key" required autocomplete="off"></label><label>Administrator name<input name="name" maxlength="100" minlength="2" required></label><label>Administrator password (12+ characters)<input type="password" name="password" minlength="12" required autocomplete="new-password"></label><label>Repeat password<input type="password" name="confirm" minlength="12" required></label><input type="hidden" name="csrf" value="'.htmlspecialchars((string)$_SESSION['csrf'],ENT_QUOTES).'"><button type="submit">Create Administrator</button></form>');
if(!hash_equals((string)$_SESSION['csrf'],(string)($_POST['csrf']??'')))page('<p>Session expired. Reload setup and try again.</p>');
if(!hash_equals(INSTALL_SECRET,(string)($_POST['key']??'')))page('<p>Invalid installation key.</p>');
$name=sclip(trim((string)($_POST['name']??'')),100);$password=(string)($_POST['password']??'');
if(iconv_strlen($name,'UTF-8')<2||strlen($password)<12||strlen($password)>128||!hash_equals($password,(string)($_POST['confirm']??'')))page('<p>Invalid name or password, or passwords do not match.</p>');
try{
 $db->beginTransaction();
 if((int)$db->query('SELECT COUNT(*) FROM admins')->fetchColumn()>0)throw new RuntimeException('Already installed.');
 q($db,'INSERT INTO admins(name,password_hash) VALUES(?,?)',[$name,password_hash($password,PASSWORD_DEFAULT)]);
 audit($db,['role'=>'admin','name'=>$name,'mobile'=>''],'setup','Initial administrator created');
 $db->commit();
 if(@file_put_contents(__DIR__.'/install.lock','Installed '.gmdate('c').'\n',LOCK_EX)===false)page('<p>Administrator created, but could not write install.lock. Create an empty <code>install.lock</code> in this folder and DELETE setup.php immediately.</p>');
 page('<p><strong>Administrator created.</strong> Open <a href="index.html">Meenu Pete Mini</a>, choose Admin, then enter the password you created.</p><p><strong>Security:</strong> Delete setup.php from hosting now. Enable SSL and schedule fish_cleanup.php as instructed in START_HERE.txt.</p>');
}catch(Throwable $e){if($db->inTransaction())$db->rollBack();page('<p>Setup failed. Check database permissions and logs. No default credentials are provided.</p>');}
