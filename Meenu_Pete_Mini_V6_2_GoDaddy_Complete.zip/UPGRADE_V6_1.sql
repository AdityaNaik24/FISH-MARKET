-- Existing V6 only. Back up first; run once. No records are deleted.
ALTER TABLE settings ADD COLUMN logo_path VARCHAR(255) NOT NULL DEFAULT '', ADD COLUMN promo_video_path VARCHAR(255) NOT NULL DEFAULT '';

CREATE TABLE IF NOT EXISTS remembered_users (
 token_hash CHAR(64) NOT NULL PRIMARY KEY,
 user_id INT UNSIGNED NOT NULL,
 expires_at DATETIME NOT NULL,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
