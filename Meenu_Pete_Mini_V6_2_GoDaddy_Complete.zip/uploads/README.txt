Upload storage. No executable files permitted.
