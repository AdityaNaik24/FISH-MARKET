-- Meenu Pete Mini V6: Apply ONCE to existing Mini V5 database only.
-- Backup database before running. Does not delete users, listings, orders, activity, or admin-only polls.
-- Do NOT re-import database.sql on an existing installation.
SET NAMES utf8mb4;
ALTER TABLE settings ADD COLUMN announcement_version INT UNSIGNED NOT NULL DEFAULT 1 AFTER announcement_text;
CREATE TABLE IF NOT EXISTS announcement_votes (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 announcement_version INT UNSIGNED NOT NULL,
 user_id INT UNSIGNED NOT NULL,
 choice ENUM('yes','no') NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY one_vote_per_announcement(announcement_version,user_id),
 INDEX ballot_tally(announcement_version,choice),
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
