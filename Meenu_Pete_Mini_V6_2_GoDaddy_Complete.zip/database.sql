-- MEENU PETE MINI V6: FRESH INSTALL ONLY. UTF8MB4 / UTC DATETIME.
-- Create empty database in cPanel and import once using phpMyAdmin.
-- DO NOT apply over any existing Meenu Pete / Meenu Pete Mini installation.
SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS settings (
 id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
 booking_validity_minutes INT UNSIGNED NOT NULL DEFAULT 30,
 fish_delete_enabled TINYINT(1) NOT NULL DEFAULT 1,
 fish_delete_hours INT UNSIGNED NOT NULL DEFAULT 7,
 announcement_enabled TINYINT(1) NOT NULL DEFAULT 0,
 announcement_text VARCHAR(350) NOT NULL DEFAULT '',
 logo_path VARCHAR(255) NOT NULL DEFAULT '',
 promo_video_path VARCHAR(255) NOT NULL DEFAULT '',
 announcement_version INT UNSIGNED NOT NULL DEFAULT 1,
 contact_name VARCHAR(100) NOT NULL DEFAULT 'Meenu Pete Support',
 contact_phone VARCHAR(16) NOT NULL DEFAULT '',
 contact_email VARCHAR(120) NOT NULL DEFAULT '',
 contact_address VARCHAR(240) NOT NULL DEFAULT '',
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO settings(id) VALUES(1);
CREATE TABLE IF NOT EXISTS admins (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 password_hash VARCHAR(255) NOT NULL,
 active TINYINT(1) NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS users (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(80) NOT NULL,
 mobile VARCHAR(10) NOT NULL UNIQUE,
 role ENUM('seller','buyer') NOT NULL,
 password_hash VARCHAR(255) NOT NULL,
 active TINYINT(1) NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS markets (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 name_en VARCHAR(120) NOT NULL,
 name_kn VARCHAR(120) NOT NULL DEFAULT '',
 active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS fish_types (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 name_en VARCHAR(120) NOT NULL,
 name_kn VARCHAR(120) NOT NULL DEFAULT '',
 active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS listings (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 seller_id INT UNSIGNED NOT NULL,
 market_id INT UNSIGNED NOT NULL,
 fish_type_id INT UNSIGNED NULL,
 unit ENUM('kg','numbers','paalu') NULL DEFAULT 'kg',
 rate DECIMAL(12,2) NOT NULL DEFAULT 0,
 total_qty DECIMAL(12,2) NOT NULL DEFAULT 0,
 sold_qty DECIMAL(12,2) NOT NULL DEFAULT 0,
 pieces_per_paalu INT UNSIGNED NULL,
 active TINYINT(1) NOT NULL DEFAULT 1,
 photo_path VARCHAR(240) NULL,
 video_path VARCHAR(240) NULL,
 posted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 deleted_at DATETIME NULL,
 INDEX(market_id,active,deleted_at), INDEX(seller_id), INDEX(posted_at),
 FOREIGN KEY(seller_id) REFERENCES users(id),
 FOREIGN KEY(market_id) REFERENCES markets(id),
 FOREIGN KEY(fish_type_id) REFERENCES fish_types(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS orders (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 listing_id INT UNSIGNED NOT NULL,
 buyer_id INT UNSIGNED NOT NULL,
 seller_id INT UNSIGNED NOT NULL,
 buyer_name VARCHAR(80) NOT NULL,
 seller_name VARCHAR(80) NOT NULL,
 fish_name VARCHAR(120) NOT NULL,
 market_name VARCHAR(120) NOT NULL,
 qty DECIMAL(12,2) NOT NULL,
 unit VARCHAR(20) NOT NULL,
 pieces_per_paalu INT UNSIGNED NULL,
 unit_price DECIMAL(12,2) NOT NULL,
 total_amount DECIMAL(14,2) NOT NULL,
 status ENUM('booked','completed','cancelled','expired') NOT NULL DEFAULT 'booked',
 expires_at_utc DATETIME NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX(status,expires_at_utc), INDEX(buyer_id,created_at), INDEX(seller_id,created_at),
 FOREIGN KEY(listing_id) REFERENCES listings(id),
 FOREIGN KEY(buyer_id) REFERENCES users(id),
 FOREIGN KEY(seller_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Public YES/NO ballots for admin-published announcements; one seller/buyer per version.
CREATE TABLE IF NOT EXISTS announcement_votes (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 announcement_version INT UNSIGNED NOT NULL,
 user_id INT UNSIGNED NOT NULL,
 choice ENUM('yes','no') NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY one_vote_per_announcement(announcement_version,user_id),
 INDEX ballot_tally(announcement_version,choice),
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS polls (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 question_en VARCHAR(220) NOT NULL,
 question_kn VARCHAR(220) NOT NULL,
 active TINYINT(1) NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS poll_options (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 poll_id INT UNSIGNED NOT NULL,
 label_en VARCHAR(180) NOT NULL,
 label_kn VARCHAR(180) NOT NULL,
 INDEX(poll_id), FOREIGN KEY(poll_id) REFERENCES polls(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS poll_votes (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 poll_id INT UNSIGNED NOT NULL,
 option_id INT UNSIGNED NOT NULL,
 admin_id INT UNSIGNED NOT NULL,
 UNIQUE KEY one_vote_per_admin(poll_id,admin_id),
 FOREIGN KEY(poll_id) REFERENCES polls(id),
 FOREIGN KEY(option_id) REFERENCES poll_options(id),
 FOREIGN KEY(admin_id) REFERENCES admins(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS activity (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 actor_role VARCHAR(16) NOT NULL,
 actor_name VARCHAR(100) NOT NULL,
 actor_mobile VARCHAR(10) NOT NULL DEFAULT '',
 action_code VARCHAR(75) NOT NULL,
 details VARCHAR(500) NOT NULL DEFAULT '',
 recorded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX(recorded_at), INDEX(action_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS login_attempts (
 identity_key CHAR(64) NOT NULL PRIMARY KEY,
 failures INT UNSIGNED NOT NULL DEFAULT 0,
 window_start DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 blocked_until DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO markets(name_en,name_kn) SELECT 'Honnavar Fish Market','ಹೊನ್ನಾವರ ಮೀನು ಮಾರುಕಟ್ಟೆ' WHERE NOT EXISTS(SELECT 1 FROM markets WHERE name_en='Honnavar Fish Market');
INSERT INTO markets(name_en,name_kn) SELECT 'Kumta Fish Market','ಕುಮಟಾ ಮೀನು ಮಾರುಕಟ್ಟೆ' WHERE NOT EXISTS(SELECT 1 FROM markets WHERE name_en='Kumta Fish Market');
INSERT INTO fish_types(name_en,name_kn) VALUES
 ('Bangude / Mackerel','ಬಂಗುಡೆ'),('Anjal / Seer Fish','ಅಂಜಲ್'),('Pomfret / Manji','ಮಾಂಜಿ'),('Sardine / Boothai','ಬೂತಾಯಿ'),('Prawns / Shrimps','ಸೀಗಡಿ'),('Crab','ಏಡಿ'),('Squid','ಕಣವ'),('Tuna','ಟ್ಯೂನಾ'),('Rohu','ರೋಹು'),('Catla','ಕಟ್ಲಾ'),('Tilapia','ತಿಲಾಪಿಯಾ'),('Pearl Spot / Karimeen','ಕರಿಮೀನ್'),('Kingfish','ಕಿಂಗ್ ಫಿಶ್'),('Anchovy','ನತ್ತಿಲಿ'),('Ribbon Fish','ರಿಬ್ಬನ್ ಮೀನು'),('Silver Fish','ಬೆಳ್ಳಿ ಮೀನು'),('Mullet','ಕೆಂಡೈ'),('Shark','ಶಾರ್ಕ್'),('Salmon','ಸಾಲ್ಮನ್'),('Barracuda','ಬರಾಕುಡಾ'),('Red Snapper','ರೆಡ್ ಸ್ನಾಪರ್'),('Lady Fish','ಲೇಡಿ ಫಿಶ್'),('Eel','ಈಲ್'),('Freshwater Prawn','ನದಿ ಸೀಗಡಿ'),('Lobster','ಲಾಬ್ಸ್ಟರ್'),('Dry Fish','ಒಣ ಮೀನು');

CREATE TABLE IF NOT EXISTS remembered_users (
 token_hash CHAR(64) NOT NULL PRIMARY KEY,
 user_id INT UNSIGNED NOT NULL,
 expires_at DATETIME NOT NULL,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
