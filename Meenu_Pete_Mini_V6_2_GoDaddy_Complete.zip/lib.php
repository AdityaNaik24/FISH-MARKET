<?php
/* Common server-side helpers for Meenu Pete Mini V5 PHP/MySQL. */
declare(strict_types=1);
require_once __DIR__.'/config.php';
date_default_timezone_set('UTC');
function database(): PDO {
    static $db = null;
    if ($db instanceof PDO) return $db;
    if (str_starts_with(DB_NAME,'REPLACE_') || str_starts_with(DB_USER,'REPLACE_')) throw new RuntimeException('Configure config.php before opening the website.');
    $db=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS,[
        PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES=>false,
    ]);
    $db->exec("SET time_zone='+00:00'");
    return $db;
}
function ensure_https(): void {
    if(!REQUIRE_HTTPS || PHP_SAPI==='cli')return;
    $https=(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off') || ($_SERVER['SERVER_PORT']??'')==='443';
    if(!$https){http_response_code(403);exit('HTTPS required. Enable SSL and open https:// address.');}
}
function session_init(): void {
    ensure_https();
    if(session_status()===PHP_SESSION_ACTIVE)return;
    session_name('meenu_mini_sid');
    session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>REQUIRE_HTTPS,'httponly'=>true,'samesite'=>'Lax']);
    session_start();
    if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(32));
}
function respond(array $payload, int $status=200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');header('X-Content-Type-Options: nosniff');
    echo json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE); exit;
}
function ok(array $data=[]): never {respond(['ok'=>true]+$data);}
function error_out(string $error,int $code=400): never{respond(['ok'=>false,'error'=>$error],$code);}
function get_setting(PDO $db): array {return $db->query('SELECT * FROM settings WHERE id=1')->fetch()?:throw new RuntimeException('Import database.sql.');}
function q(PDO $db,string $sql,array $args=[]): PDOStatement {$st=$db->prepare($sql);$st->execute($args);return $st;}
function sclip(string $s,int $n):string {return function_exists('mb_substr')?mb_substr($s,0,$n,'UTF-8'):((string)iconv_substr($s,0,$n,'UTF-8'));}
function txt(string $key,int $limit=240): string {return sclip(trim((string)($_POST[$key]??'')),$limit);}
function boolval01(mixed $v): int{return (string)$v==='1'?1:0;}
function as_int(mixed $v,int $min,int $max,string $label): int {
 if(!is_numeric($v)||!preg_match('/^\d+$/',trim((string)$v)))error_out('Invalid '.$label.'.');
 $x=(int)$v;if($x<$min||$x>$max)error_out('Invalid '.$label.'.'); return $x;
}
function as_decimal(mixed $v,float $min,float $max,string $label): float {
 if(!is_numeric($v)||!is_finite((float)$v))error_out('Invalid '.$label.'.');
 $x=(float)$v; if($x<$min||$x>$max)error_out('Invalid '.$label.'.');return round($x,2);
}
function actor(PDO $db): ?array {
 $role=$_SESSION['role']??null;$id=(int)($_SESSION['id']??0);
 if(!$role||!$id){
  $token=(string)($_COOKIE['mp_remember']??'');
  if(!preg_match('/^[a-f0-9]{64}$/',$token))return null;
  $saved=q($db,'SELECT u.id,u.role FROM remembered_users r JOIN users u ON u.id=r.user_id WHERE r.token_hash=? AND r.expires_at>UTC_TIMESTAMP() AND u.active=1',[hash('sha256',$token)])->fetch();
  if(!$saved)return null;
  session_regenerate_id(true);$_SESSION['id']=$id=(int)$saved['id'];$_SESSION['role']=$role=$saved['role'];
 }

 if($role==='admin'){$u=q($db,'SELECT id,name,active FROM admins WHERE id=?',[$id])->fetch();if(!$u||!(int)$u['active'])return null;return ['id'=>(int)$u['id'],'role'=>'admin','name'=>$u['name']];}
 if(!in_array($role,['seller','buyer'],true))return null;
 $u=q($db,'SELECT id,name,mobile,role,active FROM users WHERE id=?',[$id])->fetch();
 if(!$u||!(int)$u['active']||$u['role']!==$role)return null;
 return ['id'=>(int)$u['id'],'role'=>$u['role'],'name'=>$u['name'],'mobile'=>$u['mobile'],'active'=>(int)$u['active']];
}
function require_actor(PDO $db,array $roles=[]): array {
 $u=actor($db);if(!$u)error_out('Please log in again / ಮತ್ತೆ ಪ್ರವೇಶಿಸಿ.',401);
 if($roles&&!in_array($u['role'],$roles,true))error_out('Permission denied.',403);
 return $u;
}
function audit(PDO $db,?array $actor,string $code,string $details=''): void {
 q($db,'INSERT INTO activity(actor_role,actor_name,actor_mobile,action_code,details) VALUES(?,?,?,?,?)',[
  $actor['role']??'system',$actor['name']??'System',$actor['mobile']??'',sclip($code,75),sclip($details,500)]);
}
function public_settings(array $s): array {return [
 'logo_path'=>$s['logo_path']??'',
 'promo_video_path'=>$s['promo_video_path']??'',
 'booking_validity_minutes'=>(int)$s['booking_validity_minutes'],
 'fish_delete_enabled'=>(int)$s['fish_delete_enabled'],
 'fish_delete_hours'=>(int)$s['fish_delete_hours'],
 'announcement_enabled'=>(int)$s['announcement_enabled'],
 'announcement_text'=>$s['announcement_text'],
 'contact'=>['name'=>$s['contact_name'],'phone'=>$s['contact_phone'],'email'=>$s['contact_email'],'address'=>$s['contact_address']]
];}
function announcement_vote_summary(PDO $db,array $settings,?array $u): array {
 $version=(int)($settings['announcement_version']??1);
 $rows=q($db,'SELECT choice,COUNT(*) AS total FROM announcement_votes WHERE announcement_version=? GROUP BY choice',[$version])->fetchAll();
 $yes=0;$no=0;
 foreach($rows as $row){if($row['choice']==='yes')$yes=(int)$row['total'];elseif($row['choice']==='no')$no=(int)$row['total'];}
 $my=null;
 if($u&&in_array($u['role'],['seller','buyer'],true)){
  $record=q($db,'SELECT choice FROM announcement_votes WHERE announcement_version=? AND user_id=?',[$version,$u['id']])->fetch();
  $my=$record['choice']??null;
 }
 if(!$u||$u['role']!=='admin')return ['version'=>$version,'my_vote'=>$my];
 return ['yes'=>$yes,'no'=>$no,'total'=>$yes+$no,'version'=>$version,'my_vote'=>$my];
}
function upload_file(string $key,string $category): ?string {
 if(!isset($_FILES[$key])||!is_array($_FILES[$key])||($_FILES[$key]['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE)return null;
 $f=$_FILES[$key];if(in_array($f['error'],[UPLOAD_ERR_INI_SIZE,UPLOAD_ERR_FORM_SIZE],true))error_out('File exceeds the PHP upload limit. Increase upload_max_filesize in cPanel or use a smaller file.',413);
 if($f['error']!==UPLOAD_ERR_OK||!is_uploaded_file($f['tmp_name']))error_out('Upload was not successful. Please retry.');
 $video=$category==='video'; $limit=$video?25*1024*1024:5*1024*1024;
 if($f['size']<=0||$f['size']>$limit)error_out('File too large: photos up to 5 MB, videos up to 25 MB.');
 $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
 $allow=$video?['video/mp4'=>'mp4','video/webm'=>'webm','video/quicktime'=>'mov']:['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
 if(!isset($allow[$mime]))error_out('Unsupported photo or video file type.');
 $name=bin2hex(random_bytes(18)).'.'.$allow[$mime];$dir=__DIR__.'/uploads';
 if(!is_dir($dir)||!is_writable($dir))error_out('Upload folder is not writable.');
 if(!move_uploaded_file($f['tmp_name'],$dir.'/'.$name))error_out('Unable to store uploaded file.');
 @chmod($dir.'/'.$name,0644);return 'uploads/'.$name;
}
function unlink_media(?string $path):void{if(!$path||!preg_match('#^uploads/[a-f0-9]{36}\.(?:jpg|png|webp|mp4|webm|mov)$#',$path))return;@unlink(__DIR__.'/'.$path);}
function cleanup_expired(PDO $db,int $batch=100):array {
 $expired=0;$purged=0;$paths=[];
 // Lock all currently-expiring bookings. Do not release stock on completed orders.
 $db->beginTransaction();
 try{
  $orders=$db->query("SELECT id,listing_id,qty FROM orders WHERE status='booked' AND expires_at_utc <= UTC_TIMESTAMP() ORDER BY id LIMIT ".min(200,max(1,$batch)).' FOR UPDATE')->fetchAll();
  foreach($orders as $o){
   q($db,"UPDATE orders SET status='expired' WHERE id=? AND status='booked'",[$o['id']]);
   q($db,'UPDATE listings SET sold_qty=GREATEST(0,sold_qty-?) WHERE id=? AND deleted_at IS NULL',[$o['qty'],$o['listing_id']]);$expired++;
  }
  $s=get_setting($db);
  if((int)$s['fish_delete_enabled']===1){
   $limit=min(100,max(1,$batch));
   $st=$db->query("SELECT id,photo_path,video_path FROM listings WHERE deleted_at IS NULL AND posted_at <= DATE_SUB(UTC_TIMESTAMP(), INTERVAL ".(int)$s['fish_delete_hours']." HOUR) ORDER BY id LIMIT $limit FOR UPDATE");
   foreach($st->fetchAll() as $l){
    // Tombstone only listing content; keep stable ID, seller, market, orders, accounts and audit history.
    q($db,"UPDATE listings SET fish_type_id=NULL,unit=NULL,rate=0,total_qty=0,sold_qty=0,pieces_per_paalu=NULL,active=0,photo_path=NULL,video_path=NULL,deleted_at=UTC_TIMESTAMP() WHERE id=?",[$l['id']]);
    $paths[]=$l['photo_path'];$paths[]=$l['video_path'];
    audit($db,null,'fish_post_deleted','Listing #'.$l['id'].' cleared after '.$s['fish_delete_hours'].' hours; booking snapshots preserved');$purged++;
   }
  }
  $db->commit();
 }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
 foreach($paths as $p)unlink_media($p);
 return ['expired_bookings'=>$expired,'purged_listings'=>$purged];
}
function login_key(string $identity):string{return hash('sha256',($_SERVER['REMOTE_ADDR']??'cli').'|'.sclip($identity,100));}
function limit_login(PDO $db,string $identity):void{
 $key=login_key($identity);
 $x=q($db,'SELECT failures,window_start,blocked_until FROM login_attempts WHERE identity_key=?',[$key])->fetch();
 if($x&&$x['blocked_until']&&strtotime($x['blocked_until'].' UTC')>time())error_out('Too many login attempts. Try again later.',429);
}
function record_failed_login(PDO $db,string $identity):void{
 $key=login_key($identity);
 q($db,"INSERT INTO login_attempts(identity_key,failures,window_start,blocked_until) VALUES(?,1,UTC_TIMESTAMP(),NULL) ON DUPLICATE KEY UPDATE failures=IF(window_start<DATE_SUB(UTC_TIMESTAMP(), INTERVAL 15 MINUTE),1,failures+1),window_start=IF(window_start<DATE_SUB(UTC_TIMESTAMP(), INTERVAL 15 MINUTE),UTC_TIMESTAMP(),window_start),blocked_until=IF(failures>=6,DATE_ADD(UTC_TIMESTAMP(), INTERVAL 15 MINUTE),NULL)",[$key]);
}
function clear_failed_login(PDO $db,string $identity):void{q($db,'DELETE FROM login_attempts WHERE identity_key=?',[login_key($identity)]);}

function remember_user(PDO $db,int $id):void {
 $token=bin2hex(random_bytes(32));
 q($db,'INSERT INTO remembered_users(token_hash,user_id,expires_at) VALUES(?,?,DATE_ADD(UTC_TIMESTAMP(),INTERVAL 90 DAY))',[hash('sha256',$token),$id]);
 setcookie('mp_remember',$token,['expires'=>time()+90*86400,'path'=>'/','secure'=>REQUIRE_HTTPS,'httponly'=>true,'samesite'=>'Lax']);
}
function forget_user(PDO $db):void {
 $token=(string)($_COOKIE['mp_remember']??'');
 if($token)q($db,'DELETE FROM remembered_users WHERE token_hash=?',[hash('sha256',$token)]);
 setcookie('mp_remember','',['expires'=>time()-3600,'path'=>'/','secure'=>REQUIRE_HTTPS,'httponly'=>true,'samesite'=>'Lax']);
 unset($_COOKIE['mp_remember']);
}
