<?php
/* MEENU PETE MINI V5: configure cPanel MySQL Database details.
   Never put real credentials in source-control, screenshots, or public shares. */
const DB_HOST = 'localhost';
const DB_NAME = 'REPLACE_WITH_CPANEL_DATABASE';
const DB_USER = 'REPLACE_WITH_CPANEL_USER';
const DB_PASS = 'REPLACE_WITH_CPANEL_PASSWORD';
// Set an unpredictable 32+ character secret and keep it private.
const INSTALL_SECRET = 'REPLACE_WITH_PRIVATE_RANDOM_INSTALL_SECRET';
// Set true ONLY when the site is accessed exclusively over HTTPS.
const REQUIRE_HTTPS = true;
