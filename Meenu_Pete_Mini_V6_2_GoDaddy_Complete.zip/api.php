<?php
/* Meenu Pete MINI V5 API. Matches the quantity-bug-fixed Mini HTML, not the full Meenu Pete V5 API. */
declare(strict_types=1);
if(PHP_VERSION_ID<80200){http_response_code(503);header('Content-Type: application/json');echo json_encode(['ok'=>false,'error'=>'Select PHP 8.2 or newer in cPanel.']);exit;}
require_once __DIR__.'/lib.php';
session_init();
$action=(string)($_GET['action']??'');$method=$_SERVER['REQUEST_METHOD']??'GET';
$public_get=['bootstrap'];$authorized_get=['listings','orders','admin_dashboard','announcement_results'];
if($method==='GET'&&!in_array($action,[...$public_get,...$authorized_get],true))error_out('Unsupported GET request.',405);
if($method!=='GET'&&$method!=='POST')error_out('Method not allowed.',405);
if($method==='POST'&&empty($_POST)&&((int)($_SERVER['CONTENT_LENGTH']??0)>0))error_out('Upload exceeds the server POST limit. Increase post_max_size/upload_max_filesize in cPanel or choose a smaller file.',413);
if($method==='POST'&&!hash_equals((string)($_SESSION['csrf']??''),(string)($_POST['csrf']??'')))error_out('Security token expired. Reload the page.',419);
try {
 $db=database();
 $check=get_setting($db);
 if(!array_key_exists('logo_path',$check)||!array_key_exists('promo_video_path',$check))error_out('Database update required. The administrator must open upgrade.php and apply the V6.2 update.',503);
 try{$db->query('SELECT token_hash FROM remembered_users LIMIT 0');$db->query('SELECT id FROM announcement_votes LIMIT 0');}catch(PDOException $e){error_out('Database tables need updating. The administrator must open upgrade.php.',503);}
 // Before sensitive operations, bring reservations and listings current.
 // Batch limit and a 5-minute cron give reliable cleanup under heavy load.
 cleanup_expired($db,100);
 $settings=get_setting($db);$public=public_settings($settings);
 switch($action){
  case 'bootstrap':
   if($method!=='GET')error_out('Use GET.',405);
   $markets=$db->query('SELECT id,name_en,name_kn,active FROM markets ORDER BY id')->fetchAll();
   $fish=$db->query('SELECT id,name_en,name_kn,active FROM fish_types ORDER BY id')->fetchAll();
   $who=actor($db);ok(['markets'=>$markets,'fish_types'=>$fish,'user'=>$who,'csrf'=>$_SESSION['csrf'],'announcement_votes'=>announcement_vote_summary($db,$settings,$who)]+$public);
  case 'login':
   $role=txt('role',10);$name=txt('name',80);$mobile=preg_replace('/\D/','',txt('mobile',20));
   if(preg_match('/^91[6-9][0-9]{9}$/',$mobile))$mobile=substr($mobile,2);
   $password=bin2hex(random_bytes(32)); // Schema compatibility only; user login uses name and mobile.
   if(!in_array($role,['buyer','seller'],true)||iconv_strlen($name,'UTF-8')<2||!preg_match('/^[6-9][0-9]{9}$/',$mobile))error_out('Enter your name and a valid 10-digit mobile number.');
   if(actor($db))error_out('Log out of your current account first.');
   $identity=$role.'|'.$mobile;limit_login($db,$identity);
   $row=q($db,'SELECT id,name,mobile,role,active,password_hash FROM users WHERE mobile=?',[$mobile])->fetch();
   if($row){
    if($row['role']!==$role)error_out('This mobile already belongs to a different account role.');
    if(!(int)$row['active'])error_out('Account blocked by administrator.',403);
    if(strtolower(trim($row['name']))!==strtolower($name)){record_failed_login($db,$identity);error_out('Name does not match this mobile number.',401);}
    $id=(int)$row['id'];
   }else{
    // Login page doubles as new-account registration, preserving Mini's existing flow.
    // User-requested name/mobile entry, with no OTP verification.
    q($db,'INSERT INTO users(name,mobile,role,password_hash) VALUES(?,?,?,?)',[$name,$mobile,$role,password_hash($password,PASSWORD_DEFAULT)]);
    $id=(int)$db->lastInsertId();
   }
   clear_failed_login($db,$identity);session_regenerate_id(true);
   $_SESSION['role']=$role;$_SESSION['id']=$id;$_SESSION['csrf']=bin2hex(random_bytes(32));
   remember_user($db,$id);$u=actor($db);audit($db,$u,'user_login',$role.' account sign-in');ok(['user'=>$u]);
  case 'admin_login':
   if(actor($db))error_out('Log out first.');
   $identity='administrator';limit_login($db,$identity);
   $pass=(string)($_POST['pin']??'');$rows=$db->query('SELECT id,name,password_hash FROM admins WHERE active=1 ORDER BY id')->fetchAll();
   $found=null;
   foreach($rows as $r){if(password_verify($pass,$r['password_hash'])){$found=$r;break;}}
   if(!$found){record_failed_login($db,$identity);error_out('Incorrect administrator password.',401);}
   clear_failed_login($db,$identity);session_regenerate_id(true);
   $_SESSION['role']='admin';$_SESSION['id']=(int)$found['id'];$_SESSION['csrf']=bin2hex(random_bytes(32));
   $u=actor($db);audit($db,$u,'admin_login','Administrator sign-in');ok(['user'=>$u]);
  case 'logout':
   $u=actor($db);if($u)audit($db,$u,'logout','Signed out');
   forget_user($db);$_SESSION=[];session_regenerate_id(true);$_SESSION['csrf']=bin2hex(random_bytes(32));ok();
  case 'listings':
   $u=require_actor($db,['seller','buyer']);$mid=(int)($_GET['market_id']??0);
   $sql="SELECT l.id,l.seller_id,u.name AS seller_name,l.market_id,l.fish_type_id,l.unit,l.rate,l.total_qty,l.sold_qty,l.pieces_per_paalu,l.active,l.photo_path,l.video_path,UNIX_TIMESTAMP(l.posted_at)*1000 AS posted_at_ms FROM listings l JOIN users u ON u.id=l.seller_id WHERE l.deleted_at IS NULL";
   $params=[];if($u['role']!=='buyer'||$mid!==0){$sql.=' AND l.market_id=?';$params[]=$mid;}
   if($u['role']==='seller'){$sql.=' AND l.seller_id=?';$params[]=$u['id'];}
   else{$sql.=' AND l.active=1 AND u.active=1';}
   $sql.=' ORDER BY l.id DESC LIMIT 1000';
   $rows=q($db,$sql,$params)->fetchAll();foreach($rows as &$r)$r['deleted_at_ms']=null;unset($r);
   ok(['listings'=>$rows]);
  case 'orders':
   $u=require_actor($db,['seller','buyer']);
   // Buyer phone numbers are disclosed only to the seller who owns that order.
   // Order ownership is enforced from the authenticated server session, never a posted seller ID.
   $cols="o.id,o.listing_id,o.buyer_id,o.buyer_name,o.seller_id,o.seller_name,o.fish_name,o.market_name,o.qty,o.unit,o.pieces_per_paalu,o.unit_price,o.total_amount,o.status,o.expires_at_utc,DATE_FORMAT(CONVERT_TZ(o.created_at,'+00:00','+05:30'),'%d/%m/%Y, %h:%i %p') AS created_at";
   if($u['role']==='seller'){
    $rows=q($db,"SELECT $cols,b.mobile AS buyer_mobile FROM orders o INNER JOIN users b ON b.id=o.buyer_id WHERE o.seller_id=? ORDER BY o.id DESC LIMIT 25",[$u['id']])->fetchAll();
   }else{
    // Buyer responses do not include any other customer's phone number.
    $rows=q($db,"SELECT $cols FROM orders o WHERE o.buyer_id=? ORDER BY o.id DESC LIMIT 25",[$u['id']])->fetchAll();
   }
   ok(['orders'=>$rows]);
  case 'admin_dashboard':
   $u=require_actor($db,['admin']);
   $users=$db->query("SELECT id,name,mobile,role,role AS assigned_role,active FROM users ORDER BY id DESC LIMIT 2000")->fetchAll();
   $logs=$db->query("SELECT id,actor_role,actor_name,actor_mobile,action_code,details,DATE_FORMAT(CONVERT_TZ(recorded_at,'+00:00','+05:30'),'%d/%m/%Y, %h:%i %p') AS recorded_at FROM activity ORDER BY id DESC LIMIT 400")->fetchAll();
   $bookings=$db->query('SELECT o.id,o.buyer_name,b.mobile AS buyer_mobile,o.seller_name,o.fish_name,o.qty,o.unit,o.total_amount,o.status,o.expires_at_utc FROM orders o INNER JOIN users b ON b.id=o.buyer_id ORDER BY o.id DESC LIMIT 50')->fetchAll();
   ok(['users'=>$users,'activity'=>$logs,'bookings'=>$bookings,'announcement_votes'=>announcement_vote_summary($db,$settings,$u)]+$public);
  case 'announcement_results':
   $u=require_actor($db,['seller','buyer','admin']);
   ok(['announcement_votes'=>announcement_vote_summary($db,$settings,$u)]);
  case 'announcement_vote':
   $u=require_actor($db,['seller','buyer']);
   $choice=txt('choice',3);if(!in_array($choice,['yes','no'],true))error_out('Choose YES or NO.');
   $db->beginTransaction();
   try{
    $current=q($db,'SELECT announcement_enabled,announcement_text,announcement_version FROM settings WHERE id=1 FOR UPDATE')->fetch();
    if(!$current||(int)$current['announcement_enabled']!==1||trim($current['announcement_text'])==='')error_out('No active administrator announcement.');
    $version=(int)$current['announcement_version'];
    if((int)($_POST['version']??0)!==$version)error_out('Announcement changed. Refresh before voting.',409);
    q($db,'INSERT INTO announcement_votes(announcement_version,user_id,choice) VALUES(?,?,?)',[$version,$u['id'],$choice]);
    audit($db,$u,'announcement_vote','Announcement version #'.$version.' / '.$choice);
    $db->commit();
   }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
   $fresh=get_setting($db);
   ok(['announcement_votes'=>announcement_vote_summary($db,$fresh,$u)]);
  case 'save_listing':
   $u=require_actor($db,['seller']);
   $mid=as_int($_POST['market_id']??0,1,999999,'market');
   if(!q($db,'SELECT id FROM markets WHERE id=? AND active=1',[$mid])->fetch())error_out('Choose an active fish market.');
   $unit=txt('unit',12);if(!in_array($unit,['kg','numbers','paalu'],true))error_out('Choose kg, numbers or paalu.');
   $rate=as_decimal($_POST['rate']??'',0.01,99999999,'rate');$total=as_decimal($_POST['total_qty']??'',0,99999999,'quantity');
   if($unit!=='kg'&&floor($total)!=$total)error_out('Paalu and numbers require whole quantities.');
   $pieces=($unit==='paalu')?as_int($_POST['pieces_per_paalu']??0,1,10000,'pieces per paalu'):null;
   $id=(int)($_POST['id']??0);$old=null;
   if($id){$old=q($db,'SELECT * FROM listings WHERE id=? AND seller_id=? AND deleted_at IS NULL',[$id,$u['id']])->fetch();if(!$old)error_out('This seller listing no longer exists.',404);if($total<(float)$old['sold_qty'])error_out('Total quantity cannot be smaller than quantity already booked/completed.');}
   $other=(string)($_POST['fish_type_id']??'')==='other';$fid=$other?null:as_int($_POST['fish_type_id']??0,1,999999,'fish type');
   if(!$other&&!q($db,'SELECT id FROM fish_types WHERE id=? AND active=1',[$fid])->fetch())error_out('Select an active fish type.');
   $new_en=$other?txt('new_fish_en',120):'';$new_kn=$other?txt('new_fish_kn',120):'';
   if($other&&(iconv_strlen($new_en,'UTF-8')<2||iconv_strlen($new_kn,'UTF-8')<2))error_out('Enter new fish name in English and Kannada.');
   $photo=upload_file('photo','photo');$video=upload_file('video','video');
   $db->beginTransaction();
   try{
    if($other){$existing=q($db,'SELECT id,active FROM fish_types WHERE name_en=? LIMIT 1',[$new_en])->fetch();
     if($existing){if(!(int)$existing['active'])error_out('Fish type is disabled.');$fid=(int)$existing['id'];}
     else {q($db,'INSERT INTO fish_types(name_en,name_kn) VALUES(?,?)',[$new_en,$new_kn]);$fid=(int)$db->lastInsertId();}
    }
    if($old){
     q($db,'UPDATE listings SET fish_type_id=?,market_id=?,unit=?,rate=?,total_qty=?,pieces_per_paalu=?,photo_path=?,video_path=?,posted_at=UTC_TIMESTAMP() WHERE id=? AND seller_id=?',[
      $fid,$mid,$unit,$rate,$total,$pieces,$photo??$old['photo_path'],$video??$old['video_path'],$id,$u['id']]);
    }else{
     q($db,'INSERT INTO listings(seller_id,market_id,fish_type_id,unit,rate,total_qty,pieces_per_paalu,photo_path,video_path,posted_at) VALUES(?,?,?,?,?,?,?,?,?,UTC_TIMESTAMP())',[$u['id'],$mid,$fid,$unit,$rate,$total,$pieces,$photo,$video]);$id=(int)$db->lastInsertId();
    }
    audit($db,$u,'listing_saved','Listing #'.$id.' saved; quantity='.$total.' '.$unit);$db->commit();
   }catch(Throwable $e){if($db->inTransaction())$db->rollBack();unlink_media($photo);unlink_media($video);throw $e;}
   if($old){if($photo)unlink_media($old['photo_path']);if($video)unlink_media($old['video_path']);}
   ok(['id'=>$id]);
  case 'set_listing_active':
   $u=require_actor($db,['seller']);$id=as_int($_POST['id']??0,1,999999999,'listing');$active=boolval01($_POST['active']??0);
   $r=q($db,'UPDATE listings SET active=? WHERE id=? AND seller_id=? AND deleted_at IS NULL',[$active,$id,$u['id']]);
   if(!$r->rowCount())error_out('Seller listing not found or no change needed.');audit($db,$u,'listing_visibility','Listing #'.$id.' set to '.$active);ok();
  case 'book':case 'buy':
   $u=require_actor($db,['buyer']);$id=as_int($_POST['listing_id']??0,1,999999999,'listing');
   $n=as_decimal($_POST['qty']??'',0.01,99999999,'quantity');
   $db->beginTransaction();
   try{
    $x=q($db,'SELECT l.*,u.name AS seller_name,u.active AS seller_active,f.name_en AS fish_name,m.name_en AS market_name FROM listings l JOIN users u ON u.id=l.seller_id LEFT JOIN fish_types f ON f.id=l.fish_type_id JOIN markets m ON m.id=l.market_id WHERE l.id=? FOR UPDATE',[$id])->fetch();
    if(!$x||!(int)$x['active']||!(int)$x['seller_active']||$x['deleted_at']!==null)error_out('Fish is not available. Refresh the list.');
    if((int)$settings['fish_delete_enabled']===1 && strtotime($x['posted_at'].' UTC')+(int)$settings['fish_delete_hours']*3600<=time())error_out('Fish post has expired. Refresh available fish.');
    if($x['unit']==='kg' && $n<0.5)error_out('Minimum quantity is 0.5 kg.');
    if($x['unit']!=='kg' && ($n<1||floor($n)!=$n))error_out('Whole numbers required for paalu or numbers.');
    if($n>(float)$x['total_qty']-(float)$x['sold_qty']+0.00001)error_out('Insufficient fish stock.');
    $price=round((float)$x['rate']*$n,2);$minutes=(int)$settings['booking_validity_minutes'];
    q($db,"INSERT INTO orders(listing_id,buyer_id,seller_id,buyer_name,seller_name,fish_name,market_name,qty,unit,pieces_per_paalu,unit_price,total_amount,status,expires_at_utc) VALUES(?,?,?,?,?,?,?,?,?,?,?,?, 'booked',DATE_ADD(UTC_TIMESTAMP(), INTERVAL $minutes MINUTE))",[
     $id,$u['id'],$x['seller_id'],$u['name'],$x['seller_name'],$x['fish_name']??'Fish',$x['market_name'],$n,$x['unit'],$x['pieces_per_paalu'],$x['rate'],$price]);
    $oid=(int)$db->lastInsertId();q($db,'UPDATE listings SET sold_qty=sold_qty+? WHERE id=?',[$n,$id]);
    audit($db,$u,'booking_created','Order #'.$oid.', listing #'.$id.', '.$n.' '.$x['unit']);$db->commit();
   }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
   ok(['order_id'=>$oid,'total_amount'=>$price,'validity_minutes'=>(int)$settings['booking_validity_minutes']]);
  case 'update_booking':
   $u=require_actor($db,['admin','seller','buyer']);$oid=as_int($_POST['order_id']??0,1,2147483647,'order');$target=txt('status',15);
   if(!in_array($target,['completed','cancelled'],true))error_out('Invalid status.');
   $db->beginTransaction();
   try{
    $o=q($db,'SELECT * FROM orders WHERE id=? FOR UPDATE',[$oid])->fetch();
    if(!$o||$o['status']!=='booked'||strtotime($o['expires_at_utc'].' UTC')<=time())error_out('Only active bookings can be updated.');
    if($u['role']==='buyer'&&((int)$o['buyer_id']!==$u['id']||$target!=='cancelled'))error_out('Buyers may cancel only their own bookings.',403);
    if($u['role']==='seller'&&(int)$o['seller_id']!==$u['id'])error_out('Not your booking.',403);
    q($db,'UPDATE orders SET status=? WHERE id=?',[$target,$oid]);
    if($target==='cancelled')q($db,'UPDATE listings SET sold_qty=GREATEST(0,sold_qty-?) WHERE id=? AND deleted_at IS NULL',[$o['qty'],$o['listing_id']]);
    audit($db,$u,'booking_updated','Order #'.$oid.' => '.$target);$db->commit();
   }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
   ok();
  case 'admin_set_booking_validity':
   $u=require_actor($db,['admin']);$m=as_int($_POST['minutes']??0,5,1440,'minutes');
   q($db,'UPDATE settings SET booking_validity_minutes=? WHERE id=1',[$m]);audit($db,$u,'admin_set_booking_validity',$m.' minutes');ok(['booking_validity_minutes'=>$m]);
  case 'admin_set_fish_deletion':
   $u=require_actor($db,['admin']);$h=as_int($_POST['hours']??0,1,168,'hours');$enabled=boolval01($_POST['enabled']??0);
   q($db,'UPDATE settings SET fish_delete_enabled=?,fish_delete_hours=? WHERE id=1',[$enabled,$h]);audit($db,$u,'admin_set_fish_deletion',$enabled.' / '.$h.' hours');
   cleanup_expired($db,100);ok(['fish_delete_enabled'=>$enabled,'fish_delete_hours'=>$h]);
  case 'admin_upload_branding':
   $u=require_actor($db,['admin']);$kind=txt('kind',10);
   if(!in_array($kind,['logo','video'],true))error_out('Invalid media type.');
   $path=upload_file('media',$kind==='video'?'video':'photo');if(!$path)error_out('Choose a file.');
   $column=$kind==='logo'?'logo_path':'promo_video_path';
   q($db,"UPDATE settings SET $column=? WHERE id=1",[$path]);
   audit($db,$u,'admin_upload_branding',$kind.' updated');ok();
  case 'admin_set_announcement':
   $u=require_actor($db,['admin']);$enabled=boolval01($_POST['enabled']??0);$text=txt('text',350);
   if($enabled&&$text==='')error_out('Write an announcement before enabling it.');
   // A changed announcement text starts a new ballot; toggling visibility alone does not.
   $db->beginTransaction();
   try{
    $previous=q($db,'SELECT announcement_text,announcement_version FROM settings WHERE id=1 FOR UPDATE')->fetch();
    $version=(int)($previous['announcement_version']??1)+(($text!==($previous['announcement_text']??''))?1:0);
    q($db,'UPDATE settings SET announcement_enabled=?,announcement_text=?,announcement_version=? WHERE id=1',[$enabled,$text,$version]);
    audit($db,$u,'admin_set_announcement',($enabled?'Published':'Hidden').' / ballot #'.$version);
    $db->commit();
   }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
   ok();
  case 'admin_set_contact':
   $u=require_actor($db,['admin']);$name=txt('name',100);$phone=preg_replace('/[^+0-9]/','',txt('phone',20));$email=txt('email',120);$address=txt('address',240);
   if(!$name)error_out('Enter a support contact name.');
   if($phone&&!preg_match('/^\+?[0-9]{10,15}$/',$phone))error_out('Invalid contact phone.');
   if($email&&!filter_var($email,FILTER_VALIDATE_EMAIL))error_out('Invalid contact email.');
   q($db,'UPDATE settings SET contact_name=?,contact_phone=?,contact_email=?,contact_address=? WHERE id=1',[$name,$phone,$email,$address]);audit($db,$u,'admin_set_contact','Contact details updated');ok();
  case 'admin_add_market':case 'admin_add_fish':
   $u=require_actor($db,['admin']);$en=txt('name_en',120);$kn=txt('name_kn',120);
   if(iconv_strlen($en,'UTF-8')<2)error_out('Enter the English name.');
   $table=$action==='admin_add_market'?'markets':'fish_types';q($db,"INSERT INTO $table(name_en,name_kn) VALUES(?,?)",[$en,$kn]);
   audit($db,$u,$action,$en);ok();
  case 'admin_toggle_market':case 'admin_toggle_fish':
   $u=require_actor($db,['admin']);$id=as_int($_POST['id']??0,1,999999999,'ID');$active=boolval01($_POST['active']??0);
   $table=$action==='admin_toggle_market'?'markets':'fish_types';q($db,"UPDATE $table SET active=? WHERE id=?",[$active,$id]);
   audit($db,$u,$action,$table.' #'.$id.' active='.$active);ok();
  case 'admin_toggle_user':
   $u=require_actor($db,['admin']);$id=as_int($_POST['id']??0,1,999999999,'user');$active=boolval01($_POST['active']??0);
   q($db,'UPDATE users SET active=? WHERE id=?',[$active,$id]);audit($db,$u,'admin_toggle_user','User #'.$id.' active='.$active);ok();

  default:error_out('Unknown API action.',404);
 }
}catch(PDOException $e){
 error_log('Meenu Pete Mini PDO: '.$e->getMessage());
 if(($e->errorInfo[1]??null)===1062)error_out('This record already exists or the vote has already been counted.',409);
 error_out('Database operation failed. Check setup and server logs.',500);
}catch(Throwable $e){
 error_log('Meenu Pete Mini: '.$e->getMessage());
 error_out('Server operation failed. Check PHP setup or server logs.',500);
}
