<?php
/* Idempotent V6/V6.1 -> V6.2 upgrade. Existing admin password required. */
if (PHP_VERSION_ID < 80200) { http_response_code(503); exit('Select PHP 8.2 or newer in your hosting panel, then reload this page.'); }
require_once __DIR__.'/config.php';
if (REQUIRE_HTTPS && empty($_SERVER['HTTPS']) && ($_SERVER['SERVER_PORT']??'')!=='443') { http_response_code(403);exit('Open this page using HTTPS after enabling SSL.'); }
session_name('meenu_mini_sid');
session_set_cookie_params(['httponly'=>true,'secure'=>REQUIRE_HTTPS,'samesite'=>'Lax','path'=>'/']);
session_start();
header('Content-Type: text/html; charset=utf-8');header('Cache-Control: no-store');
if(empty($_SESSION['upgrade_csrf']))$_SESSION['upgrade_csrf']=bin2hex(random_bytes(32));
$message='Back up your website and database first. Enter your existing administrator password to add missing V6.2 fields. Existing records are preserved. Re-running this upgrade is safe.';$done=false;
if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'){
 try {
  if(!hash_equals($_SESSION['upgrade_csrf'],(string)($_POST['csrf']??'')))throw new RuntimeException('Reload this page and try again.');
  if(($_POST['backup']??'')!=='yes')throw new RuntimeException('Confirm your backup before upgrading.');
  if(time()<(int)($_SESSION['upgrade_next_try']??0))throw new RuntimeException('Wait 10 seconds before trying again.');
  $_SESSION['upgrade_next_try']=time()+10;
  if(!extension_loaded('pdo_mysql'))throw new RuntimeException('Enable pdo_mysql in the PHP selector.');
  if(str_starts_with(DB_NAME,'REPLACE_'))throw new RuntimeException('Keep your existing configured config.php. A new site needs setup.php instead.');
  $db=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
  $authenticated=false;
  foreach($db->query('SELECT password_hash FROM admins WHERE active=1')->fetchAll(PDO::FETCH_ASSOC) as $row){if(password_verify((string)($_POST['password']??''),$row['password_hash'])){$authenticated=true;break;}}
  if(!$authenticated)throw new RuntimeException('Administrator password not accepted.');
  $lock='meenu-upgrade-'.substr(hash('sha256',DB_NAME),0,32);
  $stmt=$db->prepare('SELECT GET_LOCK(?,10)');$stmt->execute([$lock]);
  if((int)$stmt->fetchColumn()!==1)throw new RuntimeException('Another upgrade is running. Try again shortly.');
  try {
   $columns=$db->query('SHOW COLUMNS FROM settings')->fetchAll(PDO::FETCH_COLUMN);
   $wanted=['announcement_version'=>'INT UNSIGNED NOT NULL DEFAULT 1','logo_path'=>"VARCHAR(255) NOT NULL DEFAULT ''",'promo_video_path'=>"VARCHAR(255) NOT NULL DEFAULT ''"];
   foreach($wanted as $name=>$definition){if(!in_array($name,$columns,true))$db->exec("ALTER TABLE settings ADD COLUMN `$name` $definition");}
   $db->exec("CREATE TABLE IF NOT EXISTS announcement_votes (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,announcement_version INT UNSIGNED NOT NULL,user_id INT UNSIGNED NOT NULL,choice ENUM('yes','no') NOT NULL,created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY one_vote_per_announcement(announcement_version,user_id),INDEX ballot_tally(announcement_version,choice),FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
   $db->exec("CREATE TABLE IF NOT EXISTS remembered_users (token_hash CHAR(64) NOT NULL PRIMARY KEY,user_id INT UNSIGNED NOT NULL,expires_at DATETIME NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
   $done=true;$message='Upgrade completed. Existing records preserved. Delete upgrade.php from hosting, open index.html, and sign in. Then run the admin hosting health check.';
  }finally{$stmt=$db->prepare('SELECT RELEASE_LOCK(?)');$stmt->execute([$lock]);}
 }catch(PDOException $e){error_log('Meenu upgrade: '.$e->getMessage());$message='Database upgrade could not finish. Check config.php, database privileges and the cPanel PHP error log. Existing records were not intentionally deleted. After fixing the cause you can re-run this page; completed additions are skipped.';}
 catch(Throwable $e){$message=$e->getMessage();}
}
?><!doctype html><html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Meenu Pete V6.2 Upgrade</title><style>body{font:16px system-ui;max-width:640px;margin:40px auto;padding:20px;background:#f1f8f8;color:#173b44}main{background:white;padding:24px;border-radius:16px}input,button{font:inherit;padding:10px;margin:12px 0}button{background:#007e80;color:white;border:0;border-radius:8px}</style><main><h1>Meenu Pete V6.2 — Upgrade</h1><p><?=htmlspecialchars($message,ENT_QUOTES,'UTF-8')?></p><?php if(!$done):?><form method="post"><input type="hidden" name="csrf" value="<?=htmlspecialchars($_SESSION['upgrade_csrf'],ENT_QUOTES,'UTF-8')?>"><label>Existing administrator password<br><input name="password" type="password" required autocomplete="current-password"></label><br><label><input type="checkbox" name="backup" value="yes" required> I have backed up files and database.</label><br><button>Apply missing updates</button></form><?php else:?><a href="index.html">Open Meenu Pete</a><?php endif;?></main></html>
