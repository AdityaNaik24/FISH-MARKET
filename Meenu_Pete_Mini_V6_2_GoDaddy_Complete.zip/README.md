# Meenu Pete Mini V6 — GoDaddy hosting (Admin Announcement + Public Yes/No Voting)

**This is the full GoDaddy website package for the separate Meenu Pete Mini application**, building on the latest buyer-mobile-number update. All approved features, including the seller's tap-to-call buyer number in Recent bookings, are preserved.

## What changed

- **Admin announcement:** The administrator enters an announcement and chooses Publish YES/NO in the admin page. This remains the only place to edit announcements.
- **Seller and buyer voting:** Each signed-in seller/buyer sees separate **YES / ಹೌದು** and **NO / ಇಲ್ಲ** buttons on the announcement near the top of their screen, plus live-on-refresh YES, NO and TOTAL counts.
- **Vote integrity:** Exactly one vote per user account per announcement text version, enforced by a MySQL unique key. Users cannot change a submitted vote. Editing announcement text starts a fresh vote count; toggling published Yes/No with unchanged text retains the count. Administrators can see the count in the announcement settings.
- **Preserved:** Existing admin-only custom polls remain admin-only, independent of the new announcement ballots. Buyers' mobile numbers remain visible only to the seller of the booking and authorized admins, not to unrelated sellers or buyers.

## Install as a brand-new site

1. Use the full ZIP. In GoDaddy cPanel create an empty MySQL database and import `database.sql` ONCE.
2. Update `config.php` with MySQL credentials and a long one-time setup secret; enable HTTPS.
3. Upload the package files to `public_html` or your selected domain folder. Retain `.htaccess` and `uploads/.htaccess`.
4. Open `setup.php` via HTTPS with the configured setup key, set the first admin password, then DELETE `setup.php`.
5. Configure cPanel Cron Jobs to execute `fish_cleanup.php` via PHP CLI every five minutes. See `START_HERE.txt` for syntax and paths.
6. Create separate seller/buyer test accounts and verify fish posting, booking, buyer contact number, announcement Yes/No voting, counting and expiry.

## Update an EXISTING Mini V5 hosted website (without data loss)

1. **Back up the full website and MySQL database.**
2. In phpMyAdmin of the **existing Mini V5 database**, apply `MIGRATE_MINI_V5_TO_V6.sql` **one time only**. It adds one settings column and a new announcement vote table; existing data is not deleted.
3. Replace **`index.html`, `api.php`, and `lib.php`** with these V6 files, and add `server_check.php` for the existing admin health-check link. Do not overwrite `config.php`, `uploads/`, or the database; do not rerun `setup.php` or re-import `database.sql`.
4. Test with a real seller and buyer account in separate browsers, and confirm announcement Yes/No totals appear to both. Record the seller's booked buyer mobile via a test order.
5. Use the `Meenu_Pete_Mini_V6_UPDATE_ONLY.zip` patch instead of the full ZIP if appropriate. It contains the three updated application files, migration, and upgrade instructions.

## Important production caveats

- The HTML link supplied separately is a **standalone browser-local preview**. Its votes are stored locally, and are not shared with other devices. Hosted accounts/votes need the PHP/MySQL site deployed.
- The web files are fully prepared, PHP and JS syntax checks are performed, and browser demos are tested. A real GoDaddy/MySQL installation, scheduled cron, and concurrent-user load are **not verified** in this environment.
- Enable **SMS OTP** and a secure password reset before unrestricted public launch; current hosted registration verifies password knowledge but not possession of a mobile number.
- V6 maintains the separate Admin-only custom voting polls; public announcement Yes/No ballots do NOT make admin polls public.
- Remember to keep server credentials private, protect uploads, and run HTTPS.



## Preserved: buyer mobile in seller Recent bookings

- After a booking, only the seller assigned to the booking sees the buyer’s registered mobile as a tap-to-call link under **Recent bookings / ಇತ್ತೀಚಿನ ಬುಕ್ಕಿಂಗ್‌ಗಳು**.
- Authorized administrators see the mobile in Booking management. Buyers and unrelated sellers cannot retrieve other buyers’ phone numbers via the order API.
- This buyer-phone feature uses the existing users/orders tables and needs **no additional schema changes** beyond the V6 announcement-voting migration described above.
