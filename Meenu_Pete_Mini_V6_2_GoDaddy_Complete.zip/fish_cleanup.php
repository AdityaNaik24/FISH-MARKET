<?php
// cPanel Cron (CLI ONLY): /usr/local/bin/php /home/CPANEL_USER/public_html/mini/fish_cleanup.php
// Run every five minutes for expiry independent of website traffic.
declare(strict_types=1);
if(PHP_SAPI!=='cli'){http_response_code(403);exit('CLI only.');}
require_once __DIR__.'/lib.php';
try{
 $db=database();$total=['expired_bookings'=>0,'purged_listings'=>0];
 for($i=0;$i<30;$i++){
  $n=cleanup_expired($db,100);
  foreach($total as $k=>$_)$total[$k]+=$n[$k];
  if($n['expired_bookings']<100&&$n['purged_listings']<100)break;
 }
 echo gmdate('c').' '.json_encode($total).PHP_EOL;
}catch(Throwable $e){fwrite(STDERR,'Cleanup failed; check PHP/MySQL configuration.'.PHP_EOL);exit(1);}
